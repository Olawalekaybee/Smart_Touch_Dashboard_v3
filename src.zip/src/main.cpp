#include <Arduino.h>
#include <lvgl.h>
#include <esp32_smartdisplay.h>

static lv_obj_t *statusLabel;
static int touchCount = 0;

static void button_event_cb(lv_event_t *event)
{
    lv_event_code_t code = lv_event_get_code(event);

    if (code == LV_EVENT_CLICKED)
    {
        touchCount++;

        char buffer[64];
        snprintf(buffer, sizeof(buffer), "Touched %d times", touchCount);

        lv_label_set_text(statusLabel, buffer);

        Serial.println("Touch detected!");
    }
}

void setup()
{
    Serial.begin(115200);
    delay(300);

    smartdisplay_init();

    lv_obj_t *title = lv_label_create(lv_screen_active());
    lv_label_set_text(title, "CYD ESP32-S3 Touch Test");
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 40);

    lv_obj_t *button = lv_button_create(lv_screen_active());
    lv_obj_set_size(button, 260, 90);
    lv_obj_center(button);
    lv_obj_add_event_cb(button, button_event_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *buttonLabel = lv_label_create(button);
    lv_label_set_text(buttonLabel, "Touch Me");
    lv_obj_center(buttonLabel);

    statusLabel = lv_label_create(lv_screen_active());
    lv_label_set_text(statusLabel, "Waiting for touch...");
    lv_obj_align(statusLabel, LV_ALIGN_BOTTOM_MID, 0, -60);

    Serial.println("Display and touch initialized!");
}

void loop()
{
    lv_timer_handler();
    delay(5);
}